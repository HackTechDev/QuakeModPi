Title       : Sword of Hell
Filename    : swordb.zip
Version     : 0.1b
Built time  : 35 minutes 
Date        : 17 juni 1997
Author      : Erik Alatalo
Email       : hoohoohoo@hotmail.com
Credits     : anyone that like credits.



Description of the Modification
-------------------------------

Tired of the axe?
Not any longer!!!

I have changed the axe to a sword..... 


How to Install the Modification
-------------------------------

Make a directory called sword in your quake directory.
Unzip "sword.zip" into the sword directory, taking care to
retain the directory structure.
     
Start Quake by typing QUAKE -GAME SWORD

Files included:
---------------------------

v_axe.mdl
config.cfg
readme.txt

Bugs
---------------------------
there is no bugs that I know about


Copyright and Distribution Permissions
--------------------------------------

Authors may not include these modifications in commercial products
without prior written permission of Erik Alatalo.

Send comments to duharfel@rocketmail.com