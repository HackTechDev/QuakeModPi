ThrowEyes 1.0
-------------

        A simple QuakeC patch that permit you to throw your eyes.

        impulse 254 throw lightning eyes
        impulse 253 destroy eyes

        Francesco Ferrara
        frank@aerre.it
